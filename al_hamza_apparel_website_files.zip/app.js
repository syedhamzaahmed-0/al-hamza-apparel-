/* Al Hamza Apparel — menu and enquiry form interactions */
(() => {
  "use strict";

  const menuButton = document.querySelector(".menu-toggle");
  const nav = document.querySelector("#primary-nav");
  const navLinks = nav ? nav.querySelectorAll("a") : [];

  function closeMenu() {
    if (!menuButton || !nav) return;
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open navigation");
    nav.classList.remove("is-open");
    document.body.classList.remove("menu-open");
  }

  if (menuButton && nav) {
    menuButton.addEventListener("click", () => {
      const isOpen = menuButton.getAttribute("aria-expanded") === "true";
      menuButton.setAttribute("aria-expanded", String(!isOpen));
      menuButton.setAttribute("aria-label", isOpen ? "Open navigation" : "Close navigation");
      nav.classList.toggle("is-open", !isOpen);
      document.body.classList.toggle("menu-open", !isOpen);
    });

    navLinks.forEach((link) => link.addEventListener("click", closeMenu));
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") closeMenu();
    });
    window.addEventListener("resize", () => {
      if (window.innerWidth > 720) closeMenu();
    });
  }

  // Product enquiry links pre-select the matching garment in the form.
  const productSelect = document.querySelector("#product-select");
  document.querySelectorAll("[data-product]").forEach((link) => {
    link.addEventListener("click", () => {
      if (!productSelect) return;
      const product = link.getAttribute("data-product");
      const option = Array.from(productSelect.options).find((item) => item.text.trim() === product);
      if (option) productSelect.value = option.value;
    });
  });

  // This static site prepares an email draft; it does not send form data to a server.
  const form = document.querySelector("#enquiry-form");
  const status = document.querySelector("#form-status");
  if (form) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!form.reportValidity()) return;

      const data = new FormData(form);
      const get = (key) => String(data.get(key) || "").trim();
      const subject = `Al Hamza Apparel enquiry — ${get("product")}`;
      const body = [
        "Hello Al Hamza Apparel,",
        "",
        "I would like to enquire about a garment project.",
        "",
        `Name: ${get("name")}`,
        `Business: ${get("business") || "Not provided"}`,
        `Email: ${get("email")}`,
        `Phone / WhatsApp: ${get("phone")}`,
        `Garment type: ${get("product")}`,
        `Estimated quantity: ${get("quantity")}`,
        "",
        "Project details:",
        get("details"),
        "",
        "Please contact me to discuss the next steps."
      ].join("\n");

      // Replace this address with your confirmed business email if it changes.
      const recipient = "alhamzagarments.official@gmail.com";
      const mailto = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      if (status) {
        status.textContent = "Your email draft is being opened. Review it and press Send in your email app.";
      }
      window.location.href = mailto;
    });
  }

  const year = document.querySelector("#current-year");
  if (year) year.textContent = String(new Date().getFullYear());
})(); 
